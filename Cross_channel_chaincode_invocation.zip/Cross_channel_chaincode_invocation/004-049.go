package main

import (
	"errors"
	"fmt"
	"log"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/hyperledger/fabric/core/chaincode/shim"
)

// contrato SimpleContract para manejar escritura y lectura desde el world-state
type SimpleContract struct {
	contractapi.Contract
}

// Crear agrega una nueva llave con valor al world-state
func (sc *SimpleContract) Crear(ctx contractapi.TransactionContextInterface, key string, value string) error {
	activoActual, err := ctx.GetStub().GetState(key)

	if err != nil {
		return errors.New("No se puede interactuar con el world state")
	}

	if activoActual != nil {
		return fmt.Errorf("No se puede crear un par en el world state con la llave %s. Ya existe", key)
	}

	err = ctx.GetStub().PutState(key, []byte(value))

	if err != nil {
		return errors.New("No se puede interactuar con el world state")
	}

	return nil
}

// -----------Cross_channel_chaincode_invocation------------
func add_number(stub *shim.ChaincodeStub, args [][]byte) ([]byte, error) {

	stub.InvokeChaincode("970000a712cf185274f39566276b18591c125ab41ee2674b3ccfeeed3e95a21b7129a4b97598e7807a362b345609caa8985f28f68e3a1614e0f12dcd99d3a589", args, "add_number")
	res := stub.InvokeChaincode("970000a712cf185274f39566276b18591c125ab41ee2674b3ccfeeed3e95a21b7129a4b97598e7807a362b345609caa8985f28f68e3a1614e0f12dcd99d3a589", args, "add_number")

	if res.Status != 200 {
		return nil, errors.New("Unable to invoke chaincode")
	}

	return nil, nil
}

// -----------Cross_channel_chaincode_invocation------------

// Leer devuelve el valor en clave en el world-state
func (sc *SimpleContract) Leer(ctx contractapi.TransactionContextInterface, key string) (string, error) {
	activoActual, err := ctx.GetStub().GetState(key)

	if err != nil {
		return "", errors.New("No se puede interactuar con el world state")
	}

	if activoActual == nil {
		return "", fmt.Errorf("No se puede leer un par en el world state con la llave %s. Ya existe", key)
	}

	return string(activoActual), nil
}

// Actualizar cambia el valor con llave en el world state
func (sc *SimpleContract) Actualizar(ctx contractapi.TransactionContextInterface, key string, value string) error {
	activoActual, err := ctx.GetStub().GetState(key)

	if err != nil {
		return errors.New("No se puede interactuar con el world state")
	}

	if activoActual == nil {
		return fmt.Errorf("No se puede actualizar un par en el world state con la llave %s. Ya existe", key)
	}

	err = ctx.GetStub().PutState(key, []byte(value))

	if err != nil {
		return errors.New("No se puede interactuar con el world state")
	}

	return nil
}

func (sc *SimpleContract) MostrarInfoStub(ctx contractapi.TransactionContextInterface) error {
	log.Println("**********************")
	log.Println("")
	log.Println("[Channel ID] ", ctx.GetStub().GetChannelID())
	log.Println("")
	log.Println("**********************")
	log.Println("")
	log.Println("[Transaction ID] ", ctx.GetStub().GetTxID())
	log.Println("")
	log.Println("**********************")

	// obteniendo el ID del cliente que invoka la TX
	identityID, err := ctx.GetClientIdentity().GetID()
	if err != nil {
		return errors.New("Obteniendo el ID del cliente")
	}

	// obteniendo el MSP-ID del cliente que invoka la TX
	mspID, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return errors.New("Obteniendo el MSP-ID del cliente")
	}

	log.Println("[Client identity] ", identityID)
	log.Println("")
	log.Println("**********************")
	log.Println("")
	log.Println("[Client MSP-ID] ", mspID)
	log.Println("")
	log.Println("**********************")
	log.Println("")
	return nil
}
